module.exports = {
  BOT_TOKEN: "7921571693:AAEShMkVK2QQMHAmea9fiHTVZbr6uqEgGxs",
};